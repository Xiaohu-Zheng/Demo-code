
%% Demo for compression process


%% Note:
% "-1" means run
% "-2" means phrase

clc
clear
%% Input��
n=5; % The number of parent nodes
N=3*ones(1,n); % The state number of all parent nodes
j3=2; % The second state of child node Ch


%% Compression process��
Ni=N(1,n);
R_now_set={}; % Intermediate variable

q=0; % The row index of a run in the run accompanying dictionary

p=0; % The row index of a phrase in the phrase accompanying dictionary

cCPT_inter={}; % Intermediate variable for the compressed column Pr(Ch|C1,C2,...,Cn)

d0_inter={}; % Intermediate variable for the phrase accompanying dictionary

d0_inter_run={}; % Intermediate variable for the run accompanying dictionary

S_all_i1=[]; % Intermediate variablefor the start row number set of all runs   
             % and phrases in the column Pr(Ch|C1,C2,...,Cn)
             
RP_i1={}; % Intermediate variable for the set of RP_j, where RP_j is the start 
          % row number set of repeated instances of a run or a phrase in the column
          
Row_number=prod(N); % Total number of NPT rows

row=1; % The row index of NPT

while row<=Row_number
    Lr=1; 
    Lp=1;
    if row==Row_number
        
        % Calculate the value in the kth row of the column Pr(Ch|C1,C2,...,Cn)
        k=row;
        [ CPTsys ] = NPT_System( n,k,N,j3);
        
        % This is run.
        r=CPTsys;
        q=q+1; % The row index of the new run in the run accompanying dictionary
        
        % This new run is stored in the run accompanying dictionary
        d0_inter_run{length(d0_inter_run)+1}=[q,r,1] ;
        
        % This new run is stored in cCPT_inter
        cCPT_inter{length(cCPT_inter)+1}=[-1,q,1];
        
        % A new Si_now is added into S_all_i1
        S_all_i1(1,length(S_all_i1)+1)=row;
        
        % A new RP_j=[Si_now] is added into RP_i1
        RP_i1{1,length(RP_i1)+1}=row;
        row=row+1;
    else
                
        % Calculate the value in the kth row of the column Pr(Ch|C1,C2,...,Cn)
        k=row;
        [ CPTsys ] = NPT_System( n,k,N,j3);
                
        % Calculate the value in the kth row of the column Pr(Ch|C1,C2,...,Cn)
        k=row+1;
        CPTsys_1= NPT_System( n,k,N,j3 ); 
        
        % The start row number of a run or a phrase
        Si_now=row;
        
        if CPTsys==CPTsys_1 % This is a run
            r=CPTsys; 
            Lr=Lr+1; % The length of a run
            S_all_i1(1,length(S_all_i1)+1)=row; % A new Si_now is added into S_all_i1
            
            % Continue to query the value in the column Pr(Ch|C1,C2,...,Cn)
            % until a value different from r is found, and end the query.
            row=row+2;
            if row<=Row_number
                k=row;
                [ CPTsys ] = NPT_System( n,k,N,j3);
                while CPTsys==r
                    Lr=Lr+1;
                    row=row+1;
                    k=row;
                    [ CPTsys ] = NPT_System( n,k,N,j3);
                    if row>Row_number
                        break;
                    end
                end
            end
            
            % Calculate intermediate variable R_alpha
            re=rem(Si_now,Ni);
            if re==1
                R_alpha=0;
            else
                if re==0
                    alpha=Ni-1;
                else
                    alpha=re-1;
                end
                R_alpha=zeros(1,alpha);
                i_alpha=alpha;
                while i_alpha>0
                    k=Si_now-i_alpha;
                    [ CPTsys ] = NPT_System( n,k,N,j3);
                    R_alpha(1,i_alpha)=CPTsys;
                    i_alpha=i_alpha-1;
                end
            end
            
            if isempty(d0_inter_run)
                run_exisit=0;
            else               
                % Call function "run_exist_decision" to determine whether the current run exists.
                [ run_exisit,cCPT_run_exist ] = run_exist_decision( R_now_set,R_alpha,cCPT_inter,d0_inter_run,S_all_i1,RP_i1,Ni,r,Lr );
            end
            
            % If run_exisit=1,this run has existed in the run accompanying dictionary. Other, this is a new run.
            if run_exisit==1    % This run has existed in the run accompanying dictionary
                
                % Update the value of nr, where nr is the number of repeated instances of
                % this run in the column Pr(Ch|C1,C2,...,Cn)
                cCPT_inter{cCPT_run_exist}(1,3)=cCPT_inter{cCPT_run_exist}(1,3)+1;
                
                % The start row number of this run is added into RP_i1
                RP_i1{1,cCPT_run_exist}(1,length(RP_i1{1,cCPT_run_exist})+1)=Si_now;
                
            else    % This is a new run
                
                % The row index of the new run in the run accompanying dictionary
                q=q+1; 
                
                % This new run is stored in the run accompanying dictionary
                d0_inter_run{length(d0_inter_run)+1}=[q,r,Lr];
                
                nr=1; % The number of repeated instances of this run in the column Pr(Ch|C1,C2,...,Cn).
                
                % This new run is stored in cCPT_inter
                l_cCPT=length(cCPT_inter);
                cCPT_inter{l_cCPT+1}=[-1,q,nr];
                
                % A new RP_j=[Si_now] is added into RP_i1
                RP_i1{1,length(RP_i1)+1}=Si_now;
                
                % Store new R_alpha into R_now_set
                R_now_set{l_cCPT+1}=R_alpha;
            end
        else %����һ��phrase
            v1=CPTsys;
            v2=CPTsys_1;
            Lp=Lp+1; % The length of a phrase
            S_all_i1(1,length(S_all_i1)+1)=row; % A new Si_now is added into S_all_i1
            
            % Continue to query the value in the column Pr(Ch|C1,C2,...,Cn)
            % until a value different from v2 is found, and end the query.
            row=row+2;
            if row<=Row_number
                k=row;
                [ CPTsys ] = NPT_System( n,k,N,j3);
                while CPTsys==v2    %
                    Lp=Lp+1;
                    row=row+1;
                    k=row;
                    [ CPTsys ] = NPT_System( n,k,N,j3);
                    if row>Row_number
                        break;
                    end
                end
            end
            
            % Calculate intermediate variable R_alpha
            re=rem(Si_now,Ni);
            if re==1
                R_alpha=0;
            else
                if re==0
                    alpha=Ni-1;
                else
                    alpha=re-1;
                end
                R_alpha=zeros(1,alpha);
                i_alpha=alpha;
                while i_alpha>0
                    k=Si_now-i_alpha;
                    [ CPTsys ] = NPT_System( n,k,N,j3);
                    R_alpha(1,i_alpha)=CPTsys;
                    i_alpha=i_alpha-1;
                end
            end
            
            if isempty(d0_inter)
                exisit=0;
            else
                % Call function "phrase_exist_decision" to determine whether the current phrase exists.
                [ exisit,cCPT_phrase_exist ] = phrase_exist_decision( R_now_set,R_alpha,cCPT_inter,d0_inter,S_all_i1,RP_i1,Ni,v1,v2,Lp );
            end
            
            % If run_exisit=1,this phrase has existed in the phrase accompanying dictionary. Other, this is a new phrase.
            if exisit==1 % This phrase has existed in the phrase accompanying dictionary
                
                % Update the value of np, where nr is the number of repeated instances of
                % this phrase in the column Pr(Ch|C1,C2,...,Cn)
                cCPT_inter{cCPT_phrase_exist}(3)=cCPT_inter{cCPT_phrase_exist}(3)+1;
                
                % The start row number of this phrase is added into RP_i1
                RP_i1{1,cCPT_phrase_exist}(1,length(RP_i1{1,cCPT_phrase_exist})+1)=Si_now;
                
            else % This a new phrase.
                
                % The row index of the new pnrase in the phrase accompanying dictionary
                p=p+1; 
                
                % This new run is stored in the phrase accompanying dictionary
                d0_inter{length(d0_inter)+1}=[p,v1,v2,Lp];
                
                np=1; % The number of repeated instances of this phrase in the column Pr(Ch|C1,C2,...,Cn).
                
                % This new phrase is stored in cCPT_inter
                l_cCPT=length(cCPT_inter);
                cCPT_inter{l_cCPT+1}=[-2,p,np];
                
                % A new RP_j=[Si_now] is added into RP_i1
                RP_i1{1,length(RP_i1)+1}=Si_now;
                
                % Store new R_alpha into R_now_set
                R_now_set{l_cCPT+1}=R_alpha;
            end
        end
    end
end

%% Output:
%The compression results:

disp('The compressed column Pr(Ch|C1,C2,...,Cn):')
cCPT_2=cell2mat(cCPT_inter')

disp('The phrase accompanying dictionary:')
d_phrase=cell2mat(d0_inter')

disp('The run accompanying dictionary:')
d_run=cell2mat(d0_inter_run')

disp('The start row number of all runs and phrases:')
S_js_all=S_all_i1

disp('The set of RP_j: ')
RP_js_all=RP_i1


