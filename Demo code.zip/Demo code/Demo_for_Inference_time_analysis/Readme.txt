The calculation time analysis includes three experiments:

(1) Perform the inference of BN by the BNT method
Folder name: Reliability_inference_BNT_method

(2) Perform the inference of BN by the proposed algorithms with computer parallel computing
Folder name: Parallel_Reliability inference_by_CA_method

(3) Perform the inference of BN by the proposed algorithms without computer parallel computing
Folder name: None_Parallel_Reliability inference_by_CA_method

-----------------------------------------------------------------------------------
For all experiments, the ".m" file is the main function:

Experiment 1: Reliability_case3_BNT.m

Experiment 2: Experiment_case2_CA_parallel.m

Experiment 3: Experiment_case2_CA_none_parallel.m
