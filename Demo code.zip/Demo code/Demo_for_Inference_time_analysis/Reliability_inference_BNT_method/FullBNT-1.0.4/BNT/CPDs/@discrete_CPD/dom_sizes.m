function sz = dom_sizes(CPD)
% DOM_SIZES Return the size of each node in the domain
% sz = dom_sizes(CPD)

sz = CPD.dom_sizes;
