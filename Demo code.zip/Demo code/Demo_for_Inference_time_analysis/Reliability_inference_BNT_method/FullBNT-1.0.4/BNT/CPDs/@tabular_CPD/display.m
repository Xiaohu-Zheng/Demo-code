function display(CPD)

disp('tabular_CPD object');
disp(struct(CPD)); 

