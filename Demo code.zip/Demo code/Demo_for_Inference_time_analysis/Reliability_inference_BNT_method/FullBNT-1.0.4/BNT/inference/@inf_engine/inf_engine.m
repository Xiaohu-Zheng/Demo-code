function engine = inf_engine(bnet)

engine.bnet = bnet;
engine = class(engine, 'inf_engine');


