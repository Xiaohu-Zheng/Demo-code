
%% Using parallel computing

%% Experiment for Case 2 by the proposed algorithms.

%% Q and E --------------------------------------------------------
% In this case, we only calculate the probability distribution of child
% node Ch,i.e. Pr(Ch). Therefore, both the query node set E and the
% evidence set are empty set.
Q=[];
E=[];

%% Node_logical----------------------------------------------------
% The variable Node_logical means the relationship between the child nodes
% Ch and its parent nodes.  The relationship mark number "1" means that the
% state of child node Ch depends on the minimum state of all parent nodes.
% This relationship has been integrated into the function "Structure_Function.p".
Node_logical=1;

%% Re_CA-----------------------------------------------------------
% Re_CA is a matrix, and each row means the probability distribution of child node Ch.
% From left to right, three columns mean the state 1, state 2 and state 3, respectively.
Re_CA=zeros(16,3);

%% t_CA------------------------------------------------------------
% For each value of n, each element of t_CA represents the time required to
% complete the inference.
t_CA=zeros(1,16);

%%
i=1;
for n=3:18 % n is the number of parent nodes of child node Ch. In this experiment, it changed from 3 to 18.
    tic
    
    N=3*ones(1,n); % The state number of all parent nodes
    N_sys=3; % The state number of child node Ch
    Pf=cell(1,n);
    for i_Pf=1:n
        Pf{1,i_Pf}=[0.01,0.02,0.97]; % The probaibility distribution of the ith node.
    end
    
    % Perform the probability inference of BN.
    [ NPT ] = Probability_Distribution_Inference_Independent( n,N,N_sys,Pf,Q,E,Node_logical );
    
    Re_CA(i,1)=NPT(1); % Probability of state 1
    Re_CA(i,2)=NPT(2); % Probability of state 2
    Re_CA(i,3)=NPT(3)  % Probability of state 3
    
    t_CA(i)=toc % Inference time
    
    i=i+1;
end